# Mr Clean

This is a small package for cleaning data. Feel free to use it to clean other, non data-related things though.
