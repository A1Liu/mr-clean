
# Global variable representing the string forms of the datatypes that pandas uses
__dtype_names = ("object","number","datetime","category","timedelta","datetimetz")